/**
 * À vous de jouer. No stress, faites de votre mieux.
 *
 * Pour rappel, n'hésitez pas à vous inspirer de ce que nous avons fait :
 * - Sur l'API Github : https://codesandbox.io/s/zqq8kykov4
 * - Sur l'API Open Weather Map : https://github.com/drazik/cours-js/tree/master/03/TD/correction
 */
