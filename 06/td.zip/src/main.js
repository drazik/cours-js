import "bootstrap/dist/css/bootstrap.css"

// Importer initResultArea du module resultArea.js
// ...

// Importer initSearchForm du module searchForm.js
// ...

// Récupérer l'élément portant l'ID result-area dans le document
// let resultAreaElement = ...

// Récupérer l'élément portant l'ID search-form dans le document
// let searchFormElement = ...

// Lancer la fonction initResultArea en lui donnant en paramètre l'élément correspondant
// let resultArea = ...

// Lancer la fonction initSearchForm en lui donnant en paramètre l'élément
// correspondant ainsi que les 3 fonctions exposées par le résultat de initResultArea
initSearchForm(/* */)
