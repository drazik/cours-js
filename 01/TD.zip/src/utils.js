/**
 * Génère un nombre entier aléatoire compris entre min et max
 *
 * @param {Number} min - La valeur minimale
 * @param {Number} max - La valeur maximale
 * @return {Number} Un nombre aléatoire compris entre min et max
 */
export function generateRandomNumber(min, max) {
  // 👉 Utilisez la fonctioin `Math.random` pour générer un nombre aléatoire
}
