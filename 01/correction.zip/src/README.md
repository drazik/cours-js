# TD 1 - Introduction au JS

Dans ce TD, nous allons développer un jeu dans lequel l'utilisateur est invité
à deviner un nombre entier généré aléatoirement entre 1 et 100.

## Récupération du code initial

Téléchargez le code initial.
