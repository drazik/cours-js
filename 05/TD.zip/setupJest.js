window.console.error = () => {}
