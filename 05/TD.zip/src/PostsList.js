import React from 'react'

export function PostsList(props) {
  return (
    <div className="posts stack stack--large js-posts-list">
      {/* Itérer sur props.post (avec la méthode map) pour afficher les posts
      en reproduisant la structure créée par la fonction createPostElement du
      TD 04 */}
    </div>
  )
}
