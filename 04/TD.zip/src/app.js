// import { initPosts } from './posts.js'
// import { initAddPostForm } from './addPostForm.js'

// let postsElement = document.querySelector('.js-posts')
// let posts = initPosts(postsElement)

// let addPostFormElement = document.querySelector('.js-add-post-form')
// initAddPostForm(addPostFormElement, posts.addPost)

async function main() {
  console.log('main')
}

main()
