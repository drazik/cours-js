/**
 * Crée un nouvel élément DOM pour un item de la liste
 *
 * @param {string} itemLabel - Le label de l'item
 *
 * @return {HTMLLiElement} L'élément créé
 */
export function createItemNode(itemLabel) {
  // 👉 Créer un élément de type li
  let item = document.createElement('li') // => <li></li>

  // 👉 Affecter la classe list__item à l'élément
  item.className = 'list__item' // => <li class="list__item"></li>

  // 👉 Créer un élément de type label
  let label = document.createElement('label') // => <label></label>
  
  // 👉 Créer un élément de type input
  let input = document.createElement('input') // => <input />

  // 👉 Affecter le type checkbox à l'input
  input.type = 'checkbox' // => <input type="checkbox" />

  // 👉 Créer un élément de type button
  let button = document.createElement('button') // => <button></button>

  // 👉 Affecter le type button au button
  button.type = 'button' // => <button type="button"></button>

  // 👉 Affecter la classe list__remove-btn au button
  button.className = 'list__remove-btn' // => <button type="button" class="list__remove-btn"></button>

  // 👉 Ajouter la chaîne '❌' dans le button
  button.append('❌') // => <button type="button" class="list__remove-btn">❌</button>

  // 👉 Affecter la valeur 'Supprimer' à l'attribut aria-label du button
  button.setAttribute('aria-label', 'Supprimer') // => <button type="button" class="list__remove-btn" aria-label="Supprimer">❌</button>

  // 👉 Ajouter l'input dans le label
  label.append(input)

  // 👉 Ajouter itemLabel dans le label
  label.append(itemLabel)

  // 👉 Ajouter le label dans l'item
  item.append(label)

  // 👉 Ajouter le button dans l'item
  item.append(button)

  /**
   * Ajoute ou supprime l'état sélectionné à l'item
   *
   * @param {Event} e
   */
  function handleSelect(e) {
    // 👉 Ajouter la classe list__item--selected à l'item si e.target.checked
    // vaut true. La retirer sinon
    let className = 'list__item--selected'
    if (e.target.checked) {
      item.classList.add(className)
    } else {
      item.classList.remove(className)
    }

    // équivalent en une ligne
    // item.classList.toggle('list__item--selected', e.target.checked)
  }

  /**
   * Supprime l'item
   */
  function handleRemove() {
    // 👉 Supprimer l'item du DOM
    item.remove()
  }

  input.addEventListener('change', handleSelect)
  button.addEventListener('click', handleRemove)


  return item
}

/**
 * Initialise la liste
 *
 * @param {HTMLUListElement} listElement - La liste d'items
 *
 * @return {Object}
 */
export function initList(listElement) {
  /**
   * Crée un nouvel item et l'ajoute à la liste
   *
   * @param {string} label
   */
  function addItem(label) {
    // 👉 Créer l'item en appelant la fonction createItemNode en lui passant le
    // label
    let item = createItemNode(label)

    // 👉 Ajouter l'item à la liste
    listElement.append(item)
  }

  return { addItem }
}
